# unbounceapi/__init__.py

__author__ = 'Yoshio Hasegawa'
__version__ = '1.1.7'

from .client import Unbounce
